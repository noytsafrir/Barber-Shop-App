package model.haircutDecorator;

public interface iHaircutStyle {
	
public int getLenght();
public int getPrice();
public int getTotalLenght();
public int getTotalPrice();
public String getName();
public String getAllStylesStrings();

}