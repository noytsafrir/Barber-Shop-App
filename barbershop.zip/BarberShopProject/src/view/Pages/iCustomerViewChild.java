package view.Pages;

import view.Pages.RootController.ViewRoot;

public interface iCustomerViewChild {
	public void setParentController(ViewRoot parent);
	public void initializePage();
}
